#!/usr/bin/env bash

echo "This is test script2 v2"

