#!/usr/bin/env bash

# This is test script v2
ls -la
